Muzaffarnagar Power Fault Large Dataset

Total rows: 20000
Rows per fault-history file: 5000
Fault-history parts: 4
Total columns: 57

Main ML targets:
1. Most_Likely_Fault -> classification
2. Actual_Restoration_Min -> regression
3. Risk_Level -> classification
4. Affected_Areas -> connected-area recommendation

Important:
- This is a realistic synthetic dataset for ML training.
- It is not an official PVVNL operational dataset.
- Network mappings are estimated and marked for verification.
- Use Source_Type and Verification_Status before presenting any record as real.

Load all parts in Python:
import pandas as pd
import glob

files = glob.glob("fault_history_part_*.csv")
df = pd.concat([pd.read_csv(file) for file in files], ignore_index=True)
print(df.shape)
